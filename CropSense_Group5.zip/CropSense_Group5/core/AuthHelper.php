<?php
function requireLogin() {
    if (!isset($_SESSION['user'])) {
        header("Location: index.php?page=dashboard");
        exit;
    }
}

function requireRole($role) {
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== $role) {
        echo "Akses ditolak!";
        exit;
    }
}
