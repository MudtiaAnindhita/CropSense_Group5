<?php
class Database {
    protected $conn; // Ubah jadi protected agar bisa diakses oleh subclass seperti Areakerja_model

    private $host = "localhost";
    private $db_name = "cropsense";
    private $username = "root";
    private $password = "";

    public function __construct() {
        $this->connect(); // langsung koneksi saat class dibuat
    }

    private function connect() {
        try {
            $this->conn = new PDO(
                "mysql:host={$this->host};dbname={$this->db_name}", 
                $this->username, 
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // ✅ Berhasil konek (hanya untuk debug, bisa dihapus di produksi)
            // echo "✅ Koneksi ke database berhasil!";
        } catch(PDOException $e) {
            // ❌ Gagal konek
            die("❌ Connection error: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->conn;
    }
    
}
