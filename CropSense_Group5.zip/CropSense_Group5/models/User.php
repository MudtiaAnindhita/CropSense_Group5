<?php
class User
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function login($username, $password)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        // GANTI INI UNTUK PASSWORD NON-HASH
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    public function getAllByRole($role)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE role = ?");
        $stmt->bind_param("s", $role);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getById($id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function create($name, $username, $password, $role)
    {
        $hash = password_hash($password, PASSWORD_DEFAULT); // Enkripsi password dulu

        $stmt = $this->conn->prepare("INSERT INTO users (name, username, password, role, created_at) VALUES (?, ?, ?, ?, NOW())");
        if (!$stmt) { 
            die("❌ Prepare gagal: " . $this->conn->error);
        }

        $stmt->bind_param("ssss", $name, $username, $hash, $role);

        if (!$stmt->execute()) {
            die("❌ Gagal simpan user: " . $stmt->error);
        }

        return true;
    }
    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }

    public function update($id, $name, $username, $role)
    {
        $stmt = $this->conn->prepare("UPDATE users SET name = ?, username = ?, role = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $username, $role, $id);
        return $stmt->execute();
    }
    public function getAllExceptAdmin()
    {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE role != 'admin'");
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    public function countKaryawan()
{
    $query = "SELECT COUNT(*) as total FROM users WHERE role = 'karyawan'";
    $result = $this->conn->query($query);

    if (!$result) {
        die("Query gagal (countKaryawan): " . $this->conn->error);
    }

    $row = $result->fetch_assoc();
    return $row['total'];
}

}
