<?php
require_once 'core/Database.php';

class Areakerja_model extends Database
{
    public function __construct()
    {
        parent::__construct();
    }

    // Ambil semua data area kerja
    public function getAll()
{
    $query = "
        SELECT u.id, u.name, 
               MAX(c.blok_lokasi) AS blok_lokasi, 
               MAX(c.tanggal_panen) AS tanggal_panen
        FROM users u
        LEFT JOIN collects c ON u.id = c.karyawan_id
        WHERE u.role = 'karyawan'
        GROUP BY u.id
        ORDER BY u.name ASC
    ";
    $stmt = $this->conn->prepare($query);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


    // Tambah area kerja baru
    public function insert($nama_lokasi)
    {
        $stmt = $this->conn->prepare("INSERT INTO area_kerja (nama_lokasi) VALUES (?)");
        $stmt->bind_param("s", $nama_lokasi);
        return $stmt->execute();
    }

    // Ambil satu area kerja berdasarkan ID
    public function getById($id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM area_kerja WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    // Update area kerja
    public function update($id, $nama_lokasi)
    {
        $stmt = $this->conn->prepare("UPDATE area_kerja SET nama_lokasi = ? WHERE id = ?");
        $stmt->bind_param("si", $nama_lokasi, $id);
        return $stmt->execute();
    }

    // Hapus area kerja
    public function delete($id)
    {
        $stmt = $this->conn->prepare("DELETE FROM area_kerja WHERE id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}
