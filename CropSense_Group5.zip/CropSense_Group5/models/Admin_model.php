<?php
class Admin_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function getUserSummary()
    {
        return $this->conn->query("SELECT role, COUNT(*) as total FROM users GROUP BY role")->fetch_all(MYSQLI_ASSOC);
    }

    public function getRecentPanen()
    {
        return $this->conn->query("SELECT * FROM collects ORDER BY tanggal_panen DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
    }
}
