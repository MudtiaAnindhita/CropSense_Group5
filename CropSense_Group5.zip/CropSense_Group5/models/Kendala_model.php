<?php
class Kendala_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');

        if ($this->conn->connect_error) {
            die("Koneksi gagal: " . $this->conn->connect_error);
        }
    }

    // ✅ Ambil semua catatan kendala + nama mandor → untuk admin
    public function getAll()
    {
        $sql = "SELECT k.*, u.name AS mandor_name
                FROM kendala k
                JOIN users u ON u.id = k.mandor_id
                WHERE k.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ORDER BY k.created_at DESC";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ✅ Simpan catatan baru → untuk mandor
    public function insert($mandor_id, $isi_catatan)
    {
        $stmt = $this->conn->prepare("INSERT INTO kendala (mandor_id, isi_catatan, tanggal, created_at) VALUES (?, ?, CURDATE(), NOW())");
        if (!$stmt) {
            die("Prepare failed: " . $this->conn->error);
        }

        $stmt->bind_param("is", $mandor_id, $isi_catatan);
        return $stmt->execute();
    }

    // ✅ Ambil catatan hanya milik mandor yg login → untuk mandor
    public function getByMandor($mandor_id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM kendala WHERE mandor_id = ? ORDER BY tanggal DESC");
        if (!$stmt) {
            die("Prepare failed: " . $this->conn->error);
        }

        $stmt->bind_param("i", $mandor_id);
        $stmt->execute();

        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // ✅ Hitung jumlah catatan hari ini
    public function countHariIni()
    {
        $sql = "SELECT COUNT(*) AS total FROM kendala WHERE tanggal = CURDATE()";
        $result = $this->conn->query($sql)->fetch_assoc();
        return $result['total'] ?? 0;
    }

    // ✅ Hitung total kendala 7 hari terakhir
    public function getJumlahKendala()
    {
        $sql = "SELECT COUNT(*) AS total FROM kendala 
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        $result = $this->conn->query($sql);
        return $result->fetch_assoc()['total'];
    }
}
