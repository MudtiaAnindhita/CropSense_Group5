<?php
class Panen_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
        if ($this->conn->connect_error) {
            die("Koneksi gagal: " . $this->conn->connect_error);
        }
    }

    // Simpan data panen dari mandor
    public function insert($data)
    {
        $query = "INSERT INTO collects 
        (mandor_id, karyawan_id, blok_lokasi, weight, grades, color, tanggal_panen)
        VALUES (?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param(
            "iisdsss",
            $data['mandor_id'],
            $data['karyawan_id'],
            $data['blok_lokasi'],
            $data['weight'],
            $data['grades'],
            $data['color'],
            $data['tanggal_panen']
        );

        return $stmt->execute();
    }

    // Ambil data panen milik mandor tertentu
    public function getByMandor($mandor_id)
    {
        $query = "SELECT c.*, u.name AS karyawan_nama
                  FROM collects c
                  JOIN users u ON c.karyawan_id = u.id
                  WHERE c.mandor_id = ?
                  ORDER BY c.tanggal_panen DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $mandor_id);
        $stmt->execute();

        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Ambil data panen milik karyawan tertentu
    public function getByKaryawan($karyawan_id)
    {
        $query = "SELECT c.*, u.name AS mandor_nama
                  FROM collects c
                  JOIN users u ON u.id = c.mandor_id
                  WHERE c.karyawan_id = ?
                  ORDER BY c.tanggal_panen DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $karyawan_id);
        $stmt->execute();

        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Data grafik performa panen
    public function getGrafikPerforma()
    {
        $sql = "SELECT tanggal_panen, SUM(weight) as total_berat
                FROM collects
                GROUP BY tanggal_panen
                ORDER BY tanggal_panen ASC";

        $result = $this->conn->query($sql);

        $grafik = [];
        while ($row = $result->fetch_assoc()) {
            $grafik[] = $row;
        }

        return $grafik;
    }

    // Semua data laporan untuk admin
    public function getAllLaporan()
    {
        $sql = "SELECT c.*, 
                       u1.name AS mandor_nama, 
                       u2.name AS karyawan_nama
                FROM collects c
                JOIN users u1 ON c.mandor_id = u1.id
                JOIN users u2 ON c.karyawan_id = u2.id
                ORDER BY c.tanggal_panen DESC";

        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Total berat panen hari ini berdasarkan mandor
    public function getTotalBeratHariIni($mandorId)
    {
        $stmt = $this->conn->prepare("
            SELECT SUM(weight) as total 
            FROM collects 
            WHERE mandor_id = ? AND tanggal_panen = CURDATE()
        ");
        $stmt->bind_param("i", $mandorId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['total'] ?? 0;
    }

    // Blok lokasi hari ini (untuk mandor)
    public function getBlokHariIni($mandorId)
    {
        $stmt = $this->conn->prepare("
            SELECT blok_lokasi FROM collects 
            WHERE mandor_id = ? AND tanggal_panen = CURDATE()
            ORDER BY id DESC LIMIT 1
        ");
        $stmt->bind_param("i", $mandorId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['blok_lokasi'] ?? null;
    }

    // Rata-rata mutu hari ini (mandor)
    public function getRataRataMutu($mandorId)
    {
        $stmt = $this->conn->prepare("
            SELECT grades FROM collects 
            WHERE mandor_id = ? AND tanggal_panen = CURDATE()
        ");
        $stmt->bind_param("i", $mandorId);
        $stmt->execute();
        $result = $stmt->get_result();

        $grades = [];
        while ($row = $result->fetch_assoc()) {
            $grades[] = $row['grades'];
        }

        if (empty($grades)) return null;

        $counts = array_count_values($grades);
        arsort($counts);
        return array_key_first($counts); // Grade yang paling sering muncul
    }

    // Total panen seluruh mandor hari ini
    public function getTotalHariIni()
    {
        $today = date('Y-m-d');

        $stmt = $this->conn->prepare("SELECT SUM(weight) as total FROM collects WHERE tanggal_panen = ?");
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['total'] ?? 0;
    }

    // Mutu terbaik berdasarkan grade terbanyak
    public function getMutuTerbaik()
    {
        $stmt = $this->conn->prepare("
        SELECT grades AS mutu, blok_lokasi AS blok, COUNT(*) as jumlah 
        FROM collects 
        GROUP BY grades, blok_lokasi 
        ORDER BY 
            CASE 
                WHEN grades = 'A' THEN 1
                WHEN grades = 'B' THEN 2
                WHEN grades = 'C' THEN 3
                ELSE 4
            END,
            jumlah DESC
        LIMIT 1
    ");
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result ?: ['mutu' => '-', 'blok' => '-'];
    }
    public function getLeaderboardMingguan()
    {
        $sql = "SELECT u.name, c.blok_lokasi, SUM(c.weight) as total_kg
            FROM collects c
            JOIN users u ON c.karyawan_id = u.id
            WHERE WEEK(c.tanggal_panen) = WEEK(CURDATE()) AND YEAR(c.tanggal_panen) = YEAR(CURDATE())
            GROUP BY c.karyawan_id, c.blok_lokasi
            ORDER BY total_kg DESC
            LIMIT 5";

        $result = $this->conn->query($sql);
        $leaderboard = [];
        $max = 0;

        while ($row = $result->fetch_assoc()) {
            if ($max === 0) $max = $row['total_kg'];
            $row['persen'] = round((($row['total_kg'] / $max) - 1) * 100);
            $leaderboard[] = $row;
        }

        return $leaderboard;
    }
    public function getDataGrafikMingguan()
    {
        $sql = "
        SELECT u.name, SUM(c.weight) as total
        FROM collects c
        JOIN users u ON u.id = c.karyawan_id
        WHERE WEEK(c.tanggal_panen) = WEEK(CURDATE()) 
        GROUP BY u.name
        ORDER BY total DESC
        LIMIT 5
    ";
        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    // Ambil total panen mingguan per mandor (TOP 5)
    public function getGrafikMingguanMandor()
    {
        $sql = "
        SELECT u.name, SUM(c.weight) as total
        FROM collects c
        JOIN users u ON u.id = c.mandor_id
        WHERE YEARWEEK(c.tanggal_panen, 1) = YEARWEEK(CURDATE(), 1)
        GROUP BY c.mandor_id
        ORDER BY total DESC
        LIMIT 5
    ";

        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Ambil total panen bulanan per mandor (TOP 5)
    public function getGrafikBulananMandor()
    {
        $sql = "
        SELECT u.name, SUM(c.weight) as total
        FROM collects c
        JOIN users u ON u.id = c.mandor_id
        WHERE MONTH(c.tanggal_panen) = MONTH(CURDATE())
        AND YEAR(c.tanggal_panen) = YEAR(CURDATE())
        GROUP BY c.mandor_id
        ORDER BY total DESC
        LIMIT 5
    ";

        $result = $this->conn->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    // Total panen hari ini untuk karyawan tertentu
    public function getTotalHariIniKaryawan($karyawan_id)
    {
        $stmt = $this->conn->prepare("SELECT SUM(weight) as total FROM collects WHERE karyawan_id = ? AND tanggal_panen = CURDATE()");
        $stmt->bind_param("i", $karyawan_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        return $result['total'] ?? 0;
    }
}
