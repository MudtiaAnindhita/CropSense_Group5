<?php
class Karyawan_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function getLeaderboard()
    {
        $sql = "SELECT u.name, COUNT(c.id) as jumlah_panen
                FROM users u
                JOIN collects c ON u.id = c.karyawan_id
                WHERE u.role = 'karyawan'
                GROUP BY u.id
                ORDER BY jumlah_panen DESC";

        return $this->conn->query($sql)->fetch_all(MYSQLI_ASSOC);
    }
    
}
