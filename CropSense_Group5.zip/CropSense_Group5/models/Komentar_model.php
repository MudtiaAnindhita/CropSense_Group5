<?php
class Komentar_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function getAll()
    {
        $sql = "SELECT k.*, u.name as karyawan_name, p.tanggal_panen 
                FROM komentar k 
                JOIN users u ON k.karyawan_id = u.id
                JOIN collects p ON k.panen_id = p.id
                ORDER BY k.tanggal_komentar DESC";
        return $this->conn->query($sql)->fetch_all(MYSQLI_ASSOC);
    }

    public function insert($panen_id, $karyawan_id, $isi_komentar)
    {
        $stmt = $this->conn->prepare("INSERT INTO komentar (panen_id, karyawan_id, isi_komentar, tanggal_komentar) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("iis", $panen_id, $karyawan_id, $isi_komentar);
        return $stmt->execute();
    }

    public function getByPanen($panen_id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM komentar WHERE panen_id = ?");
        $stmt->bind_param("i", $panen_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getByKaryawan($karyawan_id)
    {
        $stmt = $this->conn->prepare("
        SELECT k.*, u.name AS karyawan_nama, c.tanggal_panen
        FROM komentar k
        JOIN users u ON u.id = k.karyawan_id
        JOIN collects c ON k.panen_id = c.id
        WHERE k.karyawan_id = ?
        ORDER BY k.id DESC
    ");
        $stmt->bind_param("i", $karyawan_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}
