<?php
class Mandor_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function getPanenByMandor($mandor_id)
    {
        $stmt = $this->conn->prepare("SELECT * FROM collects WHERE mandor_id = ?");
        $stmt->bind_param("i", $mandor_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getAllKaryawan()
    {
        $sql = "SELECT id, name FROM users WHERE role = 'karyawan'";
        $result = $this->conn->query($sql);

        $data = [];
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }

        return $data;
    }
}
