<?php
class Grades_model
{
    private $conn;

    public function __construct()
    {
        $this->conn = new mysqli('localhost', 'root', '', 'cropsense');
    }

    public function getAll()
    {
        return $this->conn->query("SELECT * FROM grades")->fetch_all(MYSQLI_ASSOC);
    }

    public function getByName($name)
    {
        $stmt = $this->conn->prepare("SELECT * FROM grades WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }
}
