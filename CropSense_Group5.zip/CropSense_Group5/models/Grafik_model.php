<?php
require_once 'core/Database.php';

class Grafik_model extends Database
{
    public function getGrafikPanen()
    {
        $sql = "SELECT tanggal_panen, COUNT(*) AS jumlah_panen
                FROM collects
                GROUP BY tanggal_panen
                ORDER BY tanggal_panen ASC";

        // Ambil koneksi dari class Database
        $conn = $this->getConnection();

        // Jalankan query
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        // Ambil semua data dan return
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
