<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cropsense";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil hasil kerja semua karyawan
$sql = "
    SELECT u.name AS nama_karyawan, c.tanggal_panen, c.weight
    FROM collects c
    JOIN users u ON c.karyawan_id = u.id
    ORDER BY c.tanggal_panen DESC
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Hasil Pekerjaan Karyawan | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #f0f9ff, #fdf4ff);
      min-height: 100vh;
    }
  </style>
</head>
<body class="p-6">

  <div class="text-center mb-8">
    <h1 class="text-4xl font-bold text-indigo-700">📋 Hasil Pekerjaan Karyawan</h1>
    <p class="text-sm text-gray-600 mt-2">Data panen lengkap dari setiap karyawan (hanya untuk dilihat)</p>
  </div>

  <div class="max-w-6xl mx-auto bg-white rounded-3xl shadow-lg p-6">
    <table class="min-w-full table-auto border-collapse">
      <thead class="bg-indigo-100 text-indigo-800">
        <tr>
          <th class="px-4 py-3 text-left font-semibold">No</th>
          <th class="px-4 py-3 text-left font-semibold">Nama Karyawan</th>
          <th class="px-4 py-3 text-center font-semibold">Tanggal Panen</th>
          <th class="px-4 py-3 text-center font-semibold">Berat (kg)</th>
        </tr>
      </thead>
      <tbody class="text-sm text-gray-700">
        <?php if ($result && $result->num_rows > 0): $no = 1; ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50 border-b">
              <td class="px-4 py-3">#<?= $no++ ?></td>
              <td class="px-4 py-3"><?= htmlspecialchars($row['nama_karyawan']) ?></td>
              <td class="px-4 py-3 text-center"><?= date('d M Y', strtotime($row['tanggal_panen'])) ?></td>
              <td class="px-4 py-3 text-center"><?= number_format($row['weight']) ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="4" class="text-center text-gray-500 py-6">Tidak ada data hasil kerja ditemukan.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

</body>
</html>

<?php $conn->close(); ?>