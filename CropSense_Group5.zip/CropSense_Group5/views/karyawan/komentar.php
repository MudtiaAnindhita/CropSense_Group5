<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Komentar Karyawan</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe',
          },
        }
      }
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>
<body class="bg-accent min-h-screen py-10 px-4">
  <div class="max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-8">
    <h1 class="text-2xl font-bold text-primary mb-6 text-center">📝 Komentar Karyawan</h1>

    <!-- Form Komentar -->
    <form method="POST" class="space-y-4">
      <div>
        <label for="panen_id" class="block font-semibold text-gray-700 mb-1">Pilih Data Panen</label>
        <select name="panen_id" id="panen_id" required class="w-full border rounded px-3 py-2">
          <option value="">-- Pilih Tanggal Panen --</option>
          <?php foreach ($laporan as $panen): ?>
            <option value="<?= $panen['id'] ?>">
              <?= date('d M Y', strtotime($panen['tanggal_panen'])) ?> - <?= htmlspecialchars($panen['blok_lokasi']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div>
        <label for="isi_komentar" class="block font-semibold text-gray-700 mb-1">Isi Komentar</label>
        <textarea name="isi_komentar" id="isi_komentar" rows="4" class="w-full border rounded px-3 py-2" required></textarea>
      </div>

      <div class="text-right">
        <button type="submit" class="bg-primary text-white px-6 py-2 rounded hover:bg-blue-800 transition">
          Kirim Komentar
        </button>
      </div>
    </form>

    <!-- Riwayat Komentar -->
    <div class="mt-10">
      <h2 class="text-lg font-semibold text-gray-800 mb-4">📌 Komentar Anda Sebelumnya</h2>
      <?php if (!empty($list)): ?>
        <ul class="space-y-4">
          <?php foreach ($list as $komentar): ?>
            <li class="border rounded-lg p-4 bg-gray-50">
              <div class="text-sm text-gray-600 mb-1">
                Tanggal Panen: <strong><?= date('d M Y', strtotime($komentar['tanggal_panen'])) ?></strong>
              </div>
              <div class="text-gray-800"><?= nl2br(htmlspecialchars($komentar['isi_komentar'])) ?></div>
              <div class="text-right text-xs text-gray-500 mt-2">
                Dikirim: <?= date('d M Y H:i', strtotime($komentar['tanggal_komentar'])) ?>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="text-gray-500">Belum ada komentar yang Anda kirimkan.</p>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>
