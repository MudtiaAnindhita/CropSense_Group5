<?php
// views/karyawan/dashboard_karyawan.php
require_once 'core/AuthHelper.php';
requireLogin();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Karyawan | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe',
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>
<body class="bg-accent">
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-primary text-white py-6 px-5 shadow-xl flex flex-col justify-between">
      <div>
        <div class="mb-8">
          <h1 class="text-3xl font-bold">🌿 CropSense</h1>
          <p class="text-xs text-blue-200">Panel Karyawan</p>
        </div>
        <div class="mb-6">
          <?php $username = $_SESSION['user']['username'] ?? 'Pengguna'; ?>
          <div class="font-semibold">👷 <?= htmlspecialchars($username) ?></div>
          <div class="text-sm text-blue-300">Karyawan</div>
        </div>
        <nav class="space-y-2 text-sm">
          <a href="index.php?page=dashboardkaryawan" class="block py-2 px-3 rounded-lg bg-secondary hover:bg-blue-700 transition">Dashboard</a>
          <a href="index.php?page=laporanharian" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Hasil Kerja Saya</a>
          <a href="index.php?page=leaderboard" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Leaderboard</a>
          <a href="index.php?page=komentarkaryawan" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Komentar & Evaluasi</a>
        </nav>
      </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 px-10 py-8">
      <h2 class="text-3xl font-bold text-primary mb-6">Selamat Datang Karyawan</h2>

      <!-- Summary Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 mb-8">
        <!-- Total Panen Hari Ini -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-blue-500">
          <p class="text-sm text-gray-500 mb-1">Total Panen Hari Ini</p>
          <h3 class="text-2xl font-bold text-blue-700">
            <?= $totalPanenHariIni ? number_format($totalPanenHariIni, 0, ',', '.') . ' Kg' : '0 Kg' ?>
          </h3>
          <p class="text-xs text-blue-500 mt-1">⬆️ data otomatis</p>
        </div>

        <!-- Mutu Panen Terakhir -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-yellow-400">
          <p class="text-sm text-gray-500 mb-1">Mutu Panen Terakhir</p>
          <h3 class="text-xl font-semibold text-yellow-600">
            <?= $mutuTerakhir['mutu'] !== '-' ? 'Grade ' . htmlspecialchars($mutuTerakhir['mutu']) : 'Belum Ada Data' ?>
          </h3>
          <p class="text-xs text-gray-500">
            <?= $mutuTerakhir['blok'] !== '-' ? 'Blok ' . htmlspecialchars($mutuTerakhir['blok']) : 'Tidak Ada Blok' ?>
          </p>
        </div>
      </div>

    </main>
  </div>
</body>
</html>
