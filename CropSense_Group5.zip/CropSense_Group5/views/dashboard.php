<?php
// dashboard.php - Halaman pemilihan login role (Admin, Mandor, Karyawan)
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Selamat Datang | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif']
          },
          colors: {
            primary: '#1e3a8a',
            accent: '#e0f2fe',
            emerald: '#10b981'
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to right, #e0f2fe, #c7d2fe);
    }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center px-4">
  <div class="bg-white shadow-2xl rounded-3xl p-10 max-w-3xl w-full text-center">
    <h1 class="text-4xl font-bold text-primary mb-2">🌴 CropSense</h1>
    <p class="text-gray-600 mb-8 text-sm">Sistem Pemantauan Kuantitas dan Kualitas Panen Kelapa Sawit</p>

    <h2 class="text-xl font-semibold mb-4 text-gray-800">Pilih jenis akun untuk login</h2>

    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
      <!-- Admin -->
      <a href="/admin/login.php" class="bg-primary hover:bg-blue-900 py-6 px-4 rounded-xl shadow-md transform hover:scale-105 transition text-center">
        <div class="text-5xl mb-2 text-white">🧑‍💼</div>
        <div class="text-lg font-semibold text-primary bg-white inline-block px-3 py-1 rounded">Admin</div>
      </a>

      <!-- Mandor -->
      <a href="/mandor/login.php" class="bg-pink-200 hover:bg-pink-300 py-6 px-4 rounded-xl shadow-md transform hover:scale-105 transition text-center">
        <div class="text-5xl mb-2 text-white">🧑‍🌾</div>
        <div class="text-lg font-semibold text-pink-700 bg-white inline-block px-3 py-1 rounded">Mandor</div>
      </a>

      <!-- Karyawan -->
      <a href="/karyawan/login.php" class="bg-yellow-500 hover:bg-yellow-600 py-6 px-4 rounded-xl shadow-md transform hover:scale-105 transition text-center">
        <div class="text-5xl mb-2 text-white">👷</div>
        <div class="text-lg font-semibold text-yellow-700 bg-white inline-block px-3 py-1 rounded">Karyawan</div>
      </a>
    </div>
  </div>
</body>
</html>
