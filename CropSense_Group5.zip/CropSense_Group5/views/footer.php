<!-- views/partials/footer.php -->
<footer class="mt-10 py-4 text-center text-sm text-gray-500 border-t">
  &copy; <?= date('Y') ?> CropSense. All rights reserved.
</footer>
</body>
</html>
