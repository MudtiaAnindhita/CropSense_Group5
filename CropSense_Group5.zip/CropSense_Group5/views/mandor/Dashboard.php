<?php
// Dasboard.php untuk mandor
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Dashboard Mandor | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe',
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>

<body class="bg-accent">
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-primary text-white py-6 px-5 shadow-xl flex flex-col justify-between">
      <div>
        <div class="mb-8">
          <h1 class="text-3xl font-bold">🌿 CropSense</h1>
          <p class="text-xs text-blue-200">Panel Mandor</p>
        </div>
        <div class="mb-6">
          <div class="font-semibold">👷 Mandor</div>
          <div class="text-sm text-blue-300">Mandor</div>
        </div>
        <nav class="space-y-2 text-sm">
          <a href="index.php?page=dashboardmandor" class="block py-2 px-3 rounded-lg bg-secondary hover:bg-blue-700 transition">Dashboard</a>
          <a href="index.php?page=inputdata" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Input Data Hasil Panen</a>
          <a href="index.php?page=catatankendalamandor" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Catatan Kendala</a>
          <a href="index.php?page=grafik" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Grafik Performa</a>
          <a href="index.php?page=laporanharian" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Laporan Harian</a>
        </nav>

      </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 px-10 py-8">
      <?php
      require_once 'core/AuthHelper.php';
      requireLogin();

      // Ambil username dari session
      $username = $_SESSION['user']['username'] ?? 'Pengguna';
      ?>
      <h2 class="text-3xl font-bold text-primary mb-8">Selamat Datang Mandor</h2>

      <!-- Menu Navigasi Tambahan -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        <a href="#" class="bg-white p-6 rounded-xl shadow text-center hover:bg-blue-100 transition">
          <h4 class="text-lg font-semibold text-primary mb-1">📊 Grafik Performa</h4>
          <p class="text-sm text-gray-500">Lihat grafik panen tiap karyawan</p>
        </a>
        <a href="#" class="bg-white p-6 rounded-xl shadow text-center hover:bg-blue-100 transition">
          <h4 class="text-lg font-semibold text-primary mb-1">📋 Laporan Harian</h4>
          <p class="text-sm text-gray-500">Rekap kerja harian</p>
        </a>
        <a href="#" class="bg-white p-6 rounded-xl shadow text-center hover:bg-blue-100 transition">
          <h4 class="text-lg font-semibold text-primary mb-1">⚠️ Catatan Kendala</h4>
          <p class="text-sm text-gray-500">Lihat kendala lapangan</p>
        </a>
        <a href="index.php?page=inputdata" class="bg-white p-6 rounded-xl shadow text-center hover:bg-blue-100 transition">
          <h4 class="text-lg font-semibold text-primary mb-1">✏️ Input Data Panen</h4>
          <p class="text-sm text-gray-500">Tambah hasil panen hari ini</p>
        </a>

      </div>

      </div>
    </main>
  </div>
</body>

</html>