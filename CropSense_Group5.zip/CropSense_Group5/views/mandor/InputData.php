<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cropsense";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$mandor_id = $_SESSION['user']['id'] ?? null;
if (!$mandor_id) {
    die("Mandor tidak terautentikasi.");
}

// Ambil data karyawan
$karyawan = $conn->query("SELECT id, name FROM users WHERE role = 'karyawan'");

// Proses simpan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $karyawan_ids = $_POST['karyawan_id'] ?? [];
    $blok = $_POST['blok_lokasi'] ?? '';
    $berat = $_POST['weight'] ?? 0;
    $kematangan = (int) ($_POST['mutu'] ?? 0);
    $warna = $_POST['warna'] ?? '';
    $tanggal = $_POST['tanggal_panen'] ?? '';
    $description = $_POST['description'] ?? '';
    $size = $_POST['size'] ?? null;
    
    $jumlah_karyawan = count($karyawan_ids);
    $created_at = date('Y-m-d H:i:s');

    // Konversi mutu ke grade
    if ($kematangan >= 85) {
        $grade = 'A';
    } elseif ($kematangan >= 70) {
        $grade = 'B';
    } else {
        $grade = 'C';
    }

    $stmt = $conn->prepare("INSERT INTO collects (mandor_id, karyawan_id, blok_lokasi, jumlah_karyawan, description, weight, color, size, grades, tanggal_panen, created_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    foreach ($karyawan_ids as $id) {
        $stmt->bind_param(
            "iisssisssss",
            $mandor_id,
            $id,
            $blok,
            $jumlah_karyawan,
            $description,
            $berat,
            $warna,
            $size,
            $grade,
            $tanggal,
            $created_at
        );
        $stmt->execute();
    }

    $stmt->close();
    header("Location: index.php?page=inputdata");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Input Data Panen | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif']
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe'
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>
<body class="bg-accent min-h-screen py-10 px-4">
  <div class="max-w-xl mx-auto bg-white shadow-lg rounded-2xl p-8">
    <h1 class="text-3xl font-bold text-primary mb-6 text-center">✍️ Input Data Panen Hari Ini</h1>

    <form action="" method="POST" class="space-y-5">

      <!-- Karyawan -->
      <div>
        <label class="block font-semibold mb-1">Pilih Karyawan</label>
        <select name="karyawan_id[]" multiple size="5" class="w-full border rounded px-4 py-2" required>
          <?php if ($karyawan && $karyawan->num_rows > 0): ?>
            <?php while ($row = $karyawan->fetch_assoc()): ?>
              <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['name']) ?></option>
            <?php endwhile; ?>
          <?php else: ?>
            <option disabled>Tidak ada data karyawan</option>
          <?php endif; ?>
        </select>
        <small class="text-gray-500">Tekan Ctrl/Cmd untuk memilih lebih dari satu</small>
      </div>

      <!-- Blok -->
      <div>
        <label class="block font-semibold">Blok Lokasi</label>
        <input type="text" name="blok_lokasi" class="w-full border rounded px-4 py-2" required>
      </div>

      <!-- Berat -->
      <div>
        <label class="block font-semibold">Berat Panen (kg)</label>
        <input type="number" name="weight" class="w-full border rounded px-4 py-2" required>
      </div>

      <!-- Mutu -->
      <div>
        <label class="block font-semibold">Tingkat Kematangan (%)</label>
        <input type="number" name="mutu" min="0" max="100" class="w-full border rounded px-4 py-2" required>
      </div>

      <!-- Warna Buah -->
      <div>
        <label class="block font-semibold">Warna Buah</label>
        <div class="flex flex-wrap gap-4">
          <label class="flex items-center space-x-2">
            <input type="radio" name="warna" value="merah" required>
            <span class="text-red-600 font-semibold">Merah</span>
          </label>
          <label class="flex items-center space-x-2">
            <input type="radio" name="warna" value="orange" required>
            <span class="text-orange-500 font-semibold">Orange</span>
          </label>
          <label class="flex items-center space-x-2">
            <input type="radio" name="warna" value="kuning" required>
            <span class="text-yellow-500 font-semibold">Kuning</span>
          </label>
          <label class="flex items-center space-x-2">
            <input type="radio" name="warna" value="hitam" required>
            <span class="text-gray-800 font-semibold">Hitam</span>
          </label>
        </div>
      </div>

      <!-- Tanggal -->
      <div>
        <label class="block font-semibold">Tanggal Panen</label>
        <input type="date" name="tanggal_panen" class="w-full border rounded px-4 py-2" required>
      </div>

      <!-- Tombol -->
      <div class="text-center pt-4">
        <button type="submit" class="bg-primary text-white px-6 py-2 rounded-lg hover:bg-blue-800 transition">
          Simpan Data
        </button>
      </div>
    </form>
  </div>
</body>
</html>

<?php $conn->close(); ?>
