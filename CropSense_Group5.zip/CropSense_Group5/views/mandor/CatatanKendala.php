<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Catatan Kendala</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-purple-50 p-10">
  <div class="max-w-3xl mx-auto bg-white p-6 rounded-xl shadow-md">
    <h1 class="text-2xl font-bold text-purple-700 mb-4">📝 Catatan Kendala Hari Ini</h1>

    <form method="POST" class="mb-6">
      <textarea name="isi_catatan" rows="4" required class="w-full p-3 border border-purple-300 rounded-lg" placeholder="Tuliskan kendala hari ini..."></textarea>
      <button type="submit" class="mt-3 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">Kirim</button>
    </form>

    <h2 class="text-lg font-semibold text-purple-600 mb-2">Riwayat Kendala:</h2>
    <ul class="space-y-3">
      <?php foreach ($data as $row): ?>
        <li class="bg-purple-100 p-3 rounded-lg text-sm">
          <strong><?= date('d M Y H:i', strtotime($row['tanggal'])) ?>:</strong>
          <?= htmlspecialchars($row['isi_catatan']) ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>
</body>
</html>
