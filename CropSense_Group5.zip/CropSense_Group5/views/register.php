<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Registrasi Pengguna | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>
<body class="bg-blue-50 flex items-center justify-center min-h-screen px-4">
  <div class="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md">
    <h2 class="text-2xl font-bold text-center text-blue-700 mb-6">📝 Registrasi Akun</h2>

    <form method="POST" action="index.php?page=register" class="space-y-4">
      <div>
        <label class="block font-medium text-gray-700">Nama Lengkap</label>
        <input type="text" name="name" required class="w-full p-3 rounded-lg border border-gray-300 bg-blue-50" />
      </div>
      <div>
        <label class="block font-medium text-gray-700">Username</label>
        <input type="text" name="username" required class="w-full p-3 rounded-lg border border-gray-300 bg-blue-50" />
      </div>
      <div>
        <label class="block font-medium text-gray-700">Password</label>
        <input type="password" name="password" required class="w-full p-3 rounded-lg border border-gray-300 bg-blue-50" />
      </div>
      <div>
        <label class="block font-medium text-gray-700">Role</label>
        <select name="role" required class="w-full p-3 rounded-lg border border-gray-300 bg-blue-50">
          <option value="admin">Admin</option>
          <option value="mandor">Mandor</option>
          <option value="karyawan">Karyawan</option>
        </select>
      </div>

      <button type="submit" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg">
        Daftar
      </button>
    </form>

    <div class="mt-6 text-center text-sm text-blue-700">
      Sudah punya akun? <a href="index.php?page=login" class="font-semibold underline">Login</a>
    </div>
  </div>
</body>
</html>
