<!-- views/partials/navbar.php -->
<nav class="bg-primary text-white p-4 flex justify-between items-center">
  <div class="font-semibold text-xl">🌴 CropSense</div>
  <div>
    <span class="mr-4">
      Hai, <strong><?= htmlspecialchars($_SESSION['user']['name'] ?? 'Tamu') ?></strong>
      (<?= $_SESSION['user']['role'] ?? '-' ?>)
    </span>
    <a href="index.php?page=logout" class="bg-white text-primary px-3 py-1 rounded hover:bg-gray-100 transition">Logout</a>
  </div>
</nav>
