<?php
$labels = [];
$dataValues = [];

if (!empty($dataGrafik)) {
    foreach ($dataGrafik as $item) {
        $labels[] = $item['name'];
        $dataValues[] = $item['total'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Grafik Performa Mandor | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { poppins: ['Poppins', 'sans-serif'] },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe'
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
    canvas { max-height: 450px; }
  </style>
</head>
<body class="bg-accent min-h-screen p-6">
  <div class="max-w-6xl mx-auto">
    <h1 class="text-4xl font-bold text-primary mb-6 animate-pulse">📊 Grafik Performa Mandor</h1>

    <div class="bg-white rounded-3xl shadow-lg p-6 animate-fade-in">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-semibold text-gray-700">Performa Mingguan (Kg)</h2>
      </div>
      <canvas id="performaChart"></canvas>
    </div>
  </div>

  <script>
    const ctx = document.getElementById('performaChart').getContext('2d');

    const performaChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
          label: 'Total Panen',
          data: <?= json_encode($dataValues) ?>,
          backgroundColor: [
            'rgba(59, 130, 246, 0.9)',
            'rgba(34, 197, 94, 0.9)',
            'rgba(250, 204, 21, 0.9)',
            'rgba(244, 63, 94, 0.9)',
            'rgba(139, 92, 246, 0.9)'
          ],
          borderRadius: 16,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        animation: {
          duration: 1200,
          easing: 'easeOutBounce'
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function(context) {
                return context.label + ': ' + context.parsed.y + ' Kg';
              }
            }
          }
        },
        scales: {
          x: {
            ticks: { color: '#1e3a8a', font: { weight: '600' } },
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            ticks: {
              callback: value => value + ' Kg',
              color: '#6b7280'
            },
            grid: {
              borderDash: [4, 4],
              color: '#e5e7eb'
            }
          }
        }
      }
    });
  </script>
</body>
</html>
