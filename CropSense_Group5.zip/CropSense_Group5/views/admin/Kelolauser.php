<?php
// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cropsense";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data user
$sql = "SELECT id, name, username, role, created_at FROM users ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Kelola User | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #f0f9ff, #ede9fe);
      min-height: 100vh;
    }
  </style>
</head>

<body class="p-6">

  <!-- Judul Halaman -->
  <div class="text-center mb-8">
    <h1 class="text-4xl font-bold text-indigo-700">👥 Kelola Pengguna</h1>
    <p class="text-gray-600 mt-2 text-sm">Lihat, tambah, atau hapus pengguna dalam sistem CropSense</p>
  </div>

  <!-- Kontainer Tabel -->
  <div class="max-w-6xl mx-auto bg-white rounded-3xl shadow-xl p-8">

    <!-- Tombol Tambah -->
    <div class="flex justify-end mb-4">
      <a href="index.php?page=tambahuser"
        class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm px-4 py-2 rounded-lg font-semibold shadow transition">
        ➕ Tambah Pengguna
      </a>
    </div>

    <div class="overflow-x-auto rounded-lg">
      <table class="min-w-full table-auto border-collapse">
        <thead class="bg-indigo-100 text-indigo-800">
          <tr>
            <th class="px-4 py-3 text-left font-semibold">No</th>
            <th class="px-4 py-3 text-left font-semibold">Nama</th>
            <th class="px-4 py-3 text-left font-semibold">Username</th>
            <th class="px-4 py-3 text-left font-semibold">Role</th>
            <th class="px-4 py-3 text-left font-semibold">Tanggal Dibuat</th>
            <th class="px-4 py-3 text-center font-semibold">Aksi</th>
          </tr>
        </thead>
        <tbody class="text-sm text-gray-700">
          <?php if ($result && $result->num_rows > 0): $no = 1; ?>
            <?php while ($row = $result->fetch_assoc()): ?>
              <tr class="hover:bg-gray-50 transition">
                <td class="px-4 py-3"><?= $no++ ?></td>
                <td class="px-4 py-3"><?= htmlspecialchars($row['name']) ?></td>
                <td class="px-4 py-3"><?= $row['username'] ?? '<i class="text-gray-400">-</i>' ?></td>
                <td class="px-4 py-3">
                  <?php
                  $role = $row['role'];
                  $color = match ($role) {
                    'admin'    => 'bg-red-100 text-red-700',
                    'mandor'   => 'bg-yellow-100 text-yellow-700',
                    'karyawan' => 'bg-green-100 text-green-700',
                    default    => 'bg-gray-200 text-gray-800'
                  };
                  ?>
                  <span class="px-3 py-1 rounded-full text-xs font-semibold <?= $color ?>"><?= ucfirst($role) ?></span>
                </td>
                <td class="px-4 py-3"><?= date('d M Y', strtotime($row['created_at'])) ?></td>
                <td class="px-4 py-3 text-center space-x-2">
                  <a href="index.php?page=edituser&id=<?= $row['id'] ?>" class="text-blue-600 hover:underline">Edit</a> |
                  <a href="index.php?page=hapususer&id=<?= $row['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
                </td>

              </tr>
            <?php endwhile; ?>
          <?php else: ?>
            <tr>
              <td colspan="6" class="text-center text-gray-500 py-6">Belum ada pengguna terdaftar.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

</body>

</html>

<?php $conn->close(); ?>