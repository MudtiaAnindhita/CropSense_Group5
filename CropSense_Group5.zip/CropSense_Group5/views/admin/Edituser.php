<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Pengguna</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-blue-50 min-h-screen flex items-center justify-center px-4">
  <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
    <h1 class="text-2xl font-bold text-center text-blue-700 mb-6">✏️ Edit Pengguna</h1>

    <form method="POST" action="index.php?page=edituser" class="space-y-4">
      <input type="hidden" name="id" value="<?= $user['id'] ?>">

      <div>
        <label class="block font-semibold">Nama</label>
        <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required class="w-full p-3 border bg-blue-100 rounded-lg">
      </div>

      <div>
        <label class="block font-semibold">Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required class="w-full p-3 border bg-blue-100 rounded-lg">
      </div>

      <div>
        <label class="block font-semibold">Role</label>
        <select name="role" required class="w-full p-3 border bg-blue-100 rounded-lg">
          <option value="karyawan" <?= $user['role'] == 'karyawan' ? 'selected' : '' ?>>Karyawan</option>
          <option value="mandor" <?= $user['role'] == 'mandor' ? 'selected' : '' ?>>Mandor</option>
        </select>
      </div>

      <button type="submit" class="w-full py-3 bg-blue-600 text-white font-bold rounded-lg">
        Simpan Perubahan
      </button>
    </form>

    <div class="text-center mt-4">
      <a href="index.php?page=kelolauser" class="text-blue-700 hover:underline text-sm">← Kembali</a>
    </div>
  </div>
</body>
</html>
