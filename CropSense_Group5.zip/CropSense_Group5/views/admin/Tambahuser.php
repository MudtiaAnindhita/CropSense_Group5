<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Pengguna | Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
  </style>
</head>
<body class="bg-blue-50 min-h-screen flex items-center justify-center px-4">
  <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
    <h1 class="text-2xl font-bold text-center text-blue-700 mb-6">➕ Tambah Pengguna Baru</h1>

    <form method="POST" action="index.php?page=tambahuser" class="space-y-4">
      <div>
        <label class="block font-semibold text-gray-700">Nama Lengkap</label>
        <input type="text" name="name" required class="w-full p-3 bg-blue-100 border border-gray-300 rounded-lg">
      </div>
      <div>
        <label class="block font-semibold text-gray-700">Username</label>
        <input type="text" name="username" required class="w-full p-3 bg-blue-100 border border-gray-300 rounded-lg">
      </div>
      <div>
        <label class="block font-semibold text-gray-700">Password</label>
        <input type="password" name="password" required class="w-full p-3 bg-blue-100 border border-gray-300 rounded-lg">
      </div>
      <div>
        <label class="block font-semibold text-gray-700">Role</label>
        <select name="role" required class="w-full p-3 bg-blue-100 border border-gray-300 rounded-lg">
          <option value="mandor">Mandor</option>
          <option value="karyawan">Karyawan</option>
        </select>
      </div>

      <button type="submit" class="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg">
        Tambah Pengguna
      </button>
    </form>

    <div class="mt-4 text-center">
      <a href="index.php?page=kelolauser" class="text-blue-700 hover:underline text-sm">← Kembali ke Kelola User</a>
    </div>
  </div>
</body>
</html>
