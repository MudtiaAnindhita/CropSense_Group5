<?php
// Data $laporan dikirim dari controller Admin.php
// via $laporan = $panenModel->getAllLaporan();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Laporan Harian Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        poppins: ['Poppins', 'sans-serif']
                    },
                    colors: {
                        primary: '#1e3a8a',
                        secondary: '#3b82f6',
                        accent: '#e0f2fe'
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>

<body class="bg-accent min-h-screen py-10 px-4">
    <div class="max-w-7xl mx-auto bg-white shadow-lg rounded-2xl p-8">
        <h1 class="text-3xl font-bold text-primary mb-6 text-center">📊 Laporan Harian Panen (Admin)</h1>

        <?php if (!empty($laporan)): ?>
            <div class="overflow-x-auto">
                <table class="table-auto w-full border border-gray-200 text-sm">
                    <thead class="bg-primary text-white">
                        <tr>
                            <th class="px-4 py-2">No</th>
                            <th class="px-4 py-2">Nama Karyawan</th>
                            <th class="px-4 py-2">Mandor</th>
                            <th class="px-4 py-2">Blok</th>
                            <th class="px-4 py-2">Berat (kg)</th>
                            <th class="px-4 py-2">Mutu</th>
                            <th class="px-4 py-2">Warna</th>
                            <th class="px-4 py-2">Tanggal Panen</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white text-center">
                        <?php $no = 1;
                        foreach ($laporan as $row): ?>
                            <tr class="border-b hover:bg-gray-50">
                                <td class="px-4 py-2"><?= $no++ ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['karyawan_nama']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['mandor_nama']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['blok_lokasi']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['weight']) ?></td>
                                <td class="px-4 py-2"><?= htmlspecialchars($row['grades']) ?></td>
                                <td class="px-4 py-2 capitalize"><?= htmlspecialchars($row['color']) ?></td>
                                <td class="px-4 py-2"><?= date('d M Y', strtotime($row['tanggal_panen'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-center text-gray-500 mt-6">Belum ada data panen yang tersedia.</p>
        <?php endif; ?>
    </div>
</body>

</html>