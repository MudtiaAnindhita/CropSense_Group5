<?php
// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "cropsense";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data leaderboard
$sql = "
    SELECT u.name, SUM(CAST(c.weight AS UNSIGNED)) AS total_panen,
           COUNT(DISTINCT c.tanggal_panen) AS hari_panen
    FROM users u
    JOIN collects c ON u.id = c.karyawan_id
    WHERE u.role = 'karyawan'
    GROUP BY u.id
    ORDER BY total_panen DESC
";
$result = $conn->query($sql);

// Siapkan array untuk chart dan table
$labels = [];
$data = [];
$colors = [];
$tableRows = [];

$color_palette = [
  '#60a5fa', '#34d399', '#fbbf24', '#f472b6', '#a78bfa',
  '#f87171', '#2dd4bf', '#fb923c', '#22d3ee', '#a3e635'
];

$i = 0;
while ($row = $result->fetch_assoc()) {
    $labels[] = $row['name'];
    $data[] = $row['total_panen'];
    $colors[] = $color_palette[$i % count($color_palette)];
    $tableRows[] = [
        'name' => $row['name'],
        'total' => $row['total_panen'],
        'days' => $row['hari_panen']
    ];
    $i++;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Leaderboard | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #e0f2fe, #ede9fe);
    }
    canvas {
      max-height: 400px;
    }
  </style>
</head>
<body class="p-6">

  <!-- Judul -->
  <div class="text-center mb-8">
    <h1 class="text-4xl font-bold text-indigo-700">📊 Leaderboard Kinerja Karyawan</h1>
    <p class="text-gray-600 text-sm">Grafik dan tabel peringkat berdasarkan total panen</p>
  </div>

  <!-- Grafik -->
  <div class="max-w-6xl mx-auto bg-white rounded-3xl shadow-xl p-6 mb-10">
    <canvas id="leaderboardChart"></canvas>
  </div>

  <!-- Tabel Leaderboard -->
  <div class="max-w-4xl mx-auto bg-white rounded-3xl shadow-xl p-6">
    <h2 class="text-2xl font-semibold text-indigo-700 mb-4">📋 Tabel Peringkat Karyawan</h2>
    <div class="overflow-x-auto rounded-xl">
      <table class="w-full table-auto border-collapse">
        <thead class="bg-indigo-100 text-indigo-800">
          <tr>
            <th class="px-4 py-3 text-left font-semibold">Ranking</th>
            <th class="px-4 py-3 text-left font-semibold">Nama</th>
            <th class="px-4 py-3 text-center font-semibold">Total Panen (kg)</th>
            <th class="px-4 py-3 text-center font-semibold">Hari Panen</th>
          </tr>
        </thead>
        <tbody class="text-sm text-gray-700">
          <?php $rank = 1; foreach($tableRows as $row): ?>
          <tr class="hover:bg-gray-50 transition">
            <td class="px-4 py-3 font-semibold">
              <span class="text-indigo-700">#<?= $rank++ ?></span>
            </td>
            <td class="px-4 py-3"><?= htmlspecialchars($row['name']) ?></td>
            <td class="px-4 py-3 text-center"><?= number_format($row['total']) ?> kg</td>
            <td class="px-4 py-3 text-center"><?= $row['days'] ?> hari</td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Chart.js Script -->
  <script>
    const ctx = document.getElementById('leaderboardChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?= json_encode($labels) ?>,
        datasets: [{
          label: 'Total Panen (kg)',
          data: <?= json_encode($data) ?>,
          backgroundColor: <?= json_encode($colors) ?>,
          borderRadius: 10,
          barThickness: 40
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: ctx => `${ctx.raw} kg`
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { callback: val => val + ' kg' },
            title: { display: true, text: 'Total Panen (kg)' }
          },
          x: {
            ticks: { autoSkip: false, maxRotation: 40 },
            title: { display: true, text: 'Nama Karyawan' }
          }
        }
      }
    });
  </script>

</body>
</html>

<?php $conn->close(); ?>
