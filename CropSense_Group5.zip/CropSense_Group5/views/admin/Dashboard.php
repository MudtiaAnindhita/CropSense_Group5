<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Dashboard Sistem Pemantauan | CropSense</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe',
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }
  </style>
</head>

<body class="bg-accent">
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-primary text-white py-6 px-5 shadow-xl flex flex-col justify-between">
      <div>
        <div class="mb-8">
          <h1 class="text-3xl font-bold">🌿 CropSense</h1>
          <p class="text-xs text-blue-200">Monitoring Panen Sawit</p>
        </div>
        <div class="mb-6">
          <div class="font-semibold">👤 Nella Agustina</div>
          <div class="text-sm text-blue-300">Admin</div>
        </div>
        <nav class="space-y-2 text-sm">
          <p class="uppercase text-blue-200 text-xs mt-4 mb-2 tracking-wider">Menu Admin</p>
          <a href="#" class="block py-2 px-3 rounded-lg bg-secondary hover:bg-blue-700 transition">Dashboard</a>
          <a href="index.php?page=kelolauser" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Kelola Mandor & Karyawan</a>
          <a href="index.php?page=leaderboard" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Leaderboard</a>
          

          <p class="uppercase text-blue-200 text-xs mt-6 mb-2 tracking-wider">Menu Laporan</p>
          <a href="index.php?page=grafik" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Grafik Performa</a>
          <a href="index.php?page=laporanharian" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Laporan Harian</a>
          <a href="index.php?page=catatanKendala" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Catatan Kendala</a>
          <a href="index.php?page=komentar" class="block py-2 px-3 rounded-lg hover:bg-blue-700 transition">Komentar & Evaluasi</a>
        </nav>
      </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 px-10 py-8">
      <h2 class="text-4xl font-bold text-primary mb-8">Dashboard Sistem Pemantauan</h2>

      <!-- Summary Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Panen -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-blue-500">
          <p class="text-sm text-gray-500 mb-1">Total Panen Hari Ini</p>
          <h3 class="text-2xl font-bold text-blue-700">
            <?= $totalPanenHariIni ? number_format($totalPanenHariIni, 0, ',', '.') . ' Kg' : '0 Kg' ?>
          </h3>
          <p class="text-xs text-blue-500 mt-1">⬆️ data otomatis</p>
        </div>

        <!-- Karyawan Aktif -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-blue-500">
          <p class="text-sm text-gray-500 mb-1">Karyawan Aktif</p>
          <h3 class="text-2xl font-bold text-blue-600">
            <?= $jumlahKaryawan ?? 0 ?>
          </h3>
          <p class="text-xs text-blue-500 mt-1">Status aktif</p>
        </div>

        <!-- Mutu Terbaik -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-yellow-400">
          <p class="text-sm text-gray-500 mb-1">Mutu Terbaik</p>
          <h3 class="text-xl font-semibold text-yellow-600">
            <?= $mutuTerbaik['mutu'] !== '-' ? 'Grade ' . htmlspecialchars($mutuTerbaik['mutu']) : 'Belum Ada Data' ?>
          </h3>
          <p class="text-xs text-gray-500">
            <?= $mutuTerbaik['blok'] !== '-' ? 'Blok ' . htmlspecialchars($mutuTerbaik['blok']) : 'Tidak Ada Blok' ?>
          </p>
        </div>

        <!-- Kendala -->
        <div class="bg-white shadow-md rounded-xl p-5 border-t-4 border-red-400">
          <p class="text-sm text-gray-500 mb-1">Kendala Dilaporkan</p>
          <h3 class="text-2xl font-bold text-red-500">
            <?= $jumlahKendala ?? 0 ?>
          </h3>
          <p class="text-xs text-red-400">Menunggu penyelesaian</p>
        </div>
      </div>
        <div class="bg-white shadow-md rounded-xl p-5">
          <h3 class="text-lg font-semibold text-gray-700 mb-2">Leaderboard Minggu Ini</h3>
          <ul class="space-y-2 text-sm">
            <?php if (!empty($leaderboard)): ?>
              <?php foreach ($leaderboard as $i => $row): ?>
                <li>
                  <strong><?= ($i + 1) ?>. <?= htmlspecialchars($row['name']) ?></strong>
                  - Blok <?= htmlspecialchars($row['blok_lokasi']) ?> -
                  <?= number_format($row['total_kg'], 0, ',', '.') ?> kg
                  <span class="text-green-600">
                    (<?= $row['persen'] > 0 ? '+' : '' ?><?= $row['persen'] ?>%)
                  </span>
                </li>
              <?php endforeach ?>
            <?php else: ?>
              <li class="text-gray-400">Belum ada data minggu ini.</li>
            <?php endif ?>
          </ul>
        </div>

      </div>

      <!-- Aktivitas Terbaru -->
      <div class="mt-10">
        <h3 class="text-lg font-semibold text-gray-700 mb-3">Aktivitas Terkini</h3>
        <div class="bg-white shadow-md rounded-xl p-5 text-sm space-y-2">
          <p><span class="text-blue-600 font-semibold">Hermanto</span> - Blok 5 melaporkan panen 250kg Grade A</p>
          <p><span class="text-blue-500 font-semibold">Muhammad Farris</span> mengirim komentar tentang kondisi alat panen</p>
          <p><span class="text-red-500 font-semibold">Dewi Lestari</span> - Blok 3 melaporkan kendala di area panen</p>
          <p><span class="text-yellow-600 font-semibold">Agus Salim</span> - Blok 1 mencapai target panen hari ini</p>
        </div>
      </div>
    </main>
  </div>
</body>

</html>