<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Catatan Kendala | Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            background: '#f0f9ff'
          }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f0f9ff;
    }
  </style>
</head>
<body class="py-10 px-6 min-h-screen">
  <div class="max-w-5xl mx-auto bg-white shadow-md rounded-2xl p-8">
    <h1 class="text-3xl font-bold text-primary text-center mb-8">📋 Riwayat Catatan Kendala</h1>

    <?php if (!empty($data)): ?>
      <div class="space-y-5">
        <?php foreach ($data as $row): ?>
          <div class="p-5 bg-gray-50 rounded-lg border shadow-sm">
            <div class="flex justify-between items-center mb-2">
              <span class="text-sm font-semibold text-gray-700">
                Mandor: <?= isset($row['mandor_name']) ? htmlspecialchars($row['mandor_name']) : '<em class="text-gray-400">Tidak diketahui</em>' ?>
              </span>
              <span class="text-xs text-gray-500">
                <?= isset($row['tanggal']) ? date('d M Y', strtotime($row['tanggal'])) : '-' ?>
              </span>
            </div>
            <p class="text-gray-800 whitespace-pre-line leading-relaxed">
              <?= nl2br(htmlspecialchars($row['isi_catatan'] ?? '')) ?>
            </p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-center text-gray-500">Belum ada catatan kendala dari mandor.</p>
    <?php endif; ?>
  </div>
</body>
</html>
