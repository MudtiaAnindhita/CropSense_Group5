<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login Admin | CropSense</title>

  <!-- Tailwind CDN -->
  <script src="https://cdn.tailwindcss.com"></script>

  <!-- Google Fonts: Poppins -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <style>
    body {
      font-family: 'Poppins', sans-serif;
    }

    .bg-overlay {
      background: linear-gradient(rgba(219, 234, 254, 0.8), rgba(237, 233, 254, 0.8)),
        url('https://img.lovepik.com/photo/45006/9377.jpg_wh860.jpg');
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      min-height: 100vh;
    }
  </style>
</head>

<body class="bg-overlay flex items-center justify-center px-4">

  <div class="bg-white bg-opacity-95 backdrop-blur-lg p-8 rounded-3xl shadow-2xl w-full max-w-md mt-10">
    <div class="text-center">
      <h2 class="text-3xl font-bold text-indigo-700 mb-1">Selamat Datang</h2>
      <p class="text-sm text-gray-600 font-medium leading-5">
        Sistem Pemantauan Kuantitas dan Kualitas<br />Hasil Panen Kelapa Sawit
      </p>
    </div>

    <!-- Form Login -->
    <form method="POST" action="" class="mt-8 space-y-4">
      <div>
        <label for="username" class="block font-semibold text-gray-700 mb-1">Nama Pengguna</label>
        <input type="text" id="username" name="username" placeholder="Masukkan username" required
          class="w-full p-3 rounded-lg border border-gray-300 bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-indigo-400" />
      </div>

      <div>
        <label for="password" class="block font-semibold text-gray-700 mb-1">Kata Sandi</label>
        <input type="password" id="password" name="password" placeholder="Masukkan password" required
          class="w-full p-3 rounded-lg border border-gray-300 bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-indigo-400" />
      </div>

      <button type="submit"
        class="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition duration-300">
        Masuk
      </button>
    </form>

    <!-- Extra Links -->
    <!-- Tombol Kembali ke Beranda -->
    <div class="w-full text-center mt-6">
      <a href="index.php"
        class="inline-block px-6 py-3 bg-indigo-600 text-white font-bold rounded-lg shadow-md hover:bg-indigo-700 transition duration-300">
        🏠 Kembali ke Beranda
      </a>
    </div>


  </div>

</body>

</html>