<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Komentar Karyawan | Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            poppins: ['Poppins', 'sans-serif'],
          },
          colors: {
            primary: '#1e3a8a',
            secondary: '#3b82f6',
            accent: '#e0f2fe',
          }
        }
      }
    };
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #e0f2fe;
    }
  </style>
</head>
<body class="min-h-screen py-10 px-4">
  <div class="max-w-5xl mx-auto bg-white shadow-lg rounded-xl p-8">
    <h1 class="text-3xl font-bold text-primary mb-6 text-center">📋 Komentar dari Karyawan</h1>

    <?php if (!empty($data)): ?>
      <div class="space-y-6">
        <?php foreach ($data as $komentar): ?>
          <div class="border border-gray-200 rounded-lg p-5 bg-gray-50 shadow-sm">
            <div class="flex justify-between items-center mb-2">
              <div class="text-sm text-gray-700">
                <strong><?= htmlspecialchars($komentar['karyawan_name']) ?></strong> (Panen tanggal 
                <span class="text-blue-700"><?= date('d M Y', strtotime($komentar['tanggal_panen'])) ?></span>)
              </div>
              <div class="text-xs text-gray-500">
                <?= date('d M Y H:i', strtotime($komentar['tanggal_komentar'])) ?>
              </div>
            </div>
            <div class="text-gray-800 leading-relaxed whitespace-pre-line">
              <?= nl2br(htmlspecialchars($komentar['isi_komentar'])) ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-center text-gray-500">Belum ada komentar yang dikirim oleh karyawan.</p>
    <?php endif; ?>
  </div>
</body>
</html>
