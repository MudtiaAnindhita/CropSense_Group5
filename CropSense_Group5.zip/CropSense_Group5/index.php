<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


// Load semua controller
require_once 'controllers/AuthController.php';
require_once 'controllers/Admin.php';
require_once 'controllers/Mandor.php';
require_once 'controllers/Karyawan.php';

// Ambil parameter ?page=
$page = $_GET['page'] ?? 'login';

switch ($page) {
    // ============ AUTH ============
    case 'login':
        $controller = new AuthController();
        $controller->login();
        break;

    case 'logout':
        $controller = new AuthController();
        $controller->logout();
        break;

    // ============ ADMIN ============
    case 'dashboardadmin':
        $controller = new Admin();
        $controller->dashboard();
        break;

    case 'kelolauser':
        $controller = new Admin();
        $controller->kelolaUser();
        break;

    case 'statususer':
        $controller = new Admin();
        $controller->statusUser();
        break;

    case 'komentar':
        $controller = new Admin();
        $controller->komentar();
        break;

    case 'leaderboard':
        $controller = new Admin();
        $controller->leaderboard();
        break;


    case 'grafik':
        $controller = new Admin();
        $controller->grafik();
        break;


    case 'laporanharian':
        $controller = new Admin();
        $controller->laporanharian();
        break;

    case 'tambahuser':
        $controller = new Admin();
        $controller->tambahUser();
        break;

    case 'catatanKendala':
        $controller = new Admin();
        $controller->catatanKendala();
        break;

    case 'edituser':
        $controller = new Admin();
        $controller->editUser();
        break;

    case 'hapususer':
        $controller = new Admin();
        $controller->hapusUser();
        break;


    // ============ MANDOR ============
    case 'dashboardmandor':
        $controller = new Mandor();
        $controller->dashboard();
        break;

    case 'grafik':
        $controller = new Mandor();
        $controller->grafik();
        break;

    case 'inputdata':
        $controller = new Mandor();
        $controller->inputData();
        break;

    case 'laporanharian':
        $controller = new Mandor();
        $controller->laporanHarian();
        break;

    case 'catatankendalamandor':
        $controller = new Mandor();
        $controller->catatankendalamandor();
        break;
    // ============ KARYAWAN ============
    case 'dashboardkaryawan':
        $controller = new Karyawan();
        $controller->dashboardKaryawan();
        break;

    case 'laporanharian':
        $controller = new Karyawan();
        $controller->laporanharian();
        break;

    case 'komentarkaryawan':
        $controller = new Karyawan();
        $controller->komentarkaryawan();
        break;

    // ============ DEFAULT ============

    default:
        echo "<h2>404 - Halaman tidak ditemukan</h2>";
        break;
}
