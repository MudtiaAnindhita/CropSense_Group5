<?php
require_once 'models/Admin_model.php';
require_once 'models/User.php';
require_once 'models/Panen_model.php';
require_once 'models/Kendala_model.php';
require_once 'core/AuthHelper.php';

class Admin
{
    public function dashboard()
    {
        $panenModel    = new Panen_model();
        $kendalaModel  = new Kendala_model();
        $userModel     = new User();

        $totalPanenHariIni = $panenModel->getTotalHariIni();
        $mutuTerbaik       = $panenModel->getMutuTerbaik();
        $jumlahKaryawan    = $userModel->countKaryawan();
        $jumlahKendala     = $kendalaModel->getJumlahKendala();
        $leaderboard       = $panenModel->getLeaderboardMingguan();

        require_once 'views/admin/dashboard.php';
    }


    public function statusUser()
    {
        $user = new User();
        $list = $user->getAllByRole('mandor');

        include 'views/admin/StatusUser.php';
    }

    public function komentar()
    {
        require_once 'models/Komentar_model.php';
        $komentarModel = new Komentar_model();
        $data = $komentarModel->getAll();

        include 'views/admin/Komentar.php';
    }

    public function leaderboard()
    {
        require_once 'models/Karyawan_model.php';
        $karyawanModel = new Karyawan_model();
        $data = $karyawanModel->getLeaderboard();

        include 'views/admin/Leaderboard.php';
    }

    public function grafik()
    {
        $panenModel = new Panen_model();
        $dataGrafik = $panenModel->getGrafikMingguanMandor(); // Default mingguan

        include 'views/admin/grafik.php'; // untuk Admin.php
    }


    public function catatanKendala()
    {
        require_once 'models/Kendala_model.php';
        $kendalaModel = new Kendala_model();
        $data = $kendalaModel->getAll();

        include 'views/admin/Catatankendala.php';
    }

    public function laporanharian()
    {
        $panenModel = new Panen_model();
        $laporan = $panenModel->getAllLaporan();

        include 'views/admin/LaporanHarian.php';
    }

    public function tambahUser()
    {
        $user = new User();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $name     = $_POST['name'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $role     = $_POST['role'];

            $success = $user->create($name, $username, $password, $role);

            if (!$success) {
                echo "<script>alert('❌ Username sudah digunakan.'); window.location='index.php?page=tambahuser';</script>";
                exit;
            }

            header("Location: index.php?page=kelolauser");
            exit;
        }

        include 'views/admin/Tambahuser.php';
    }

    public function hapusUser()
    {
        $userModel = new User();

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $userModel->delete($id);
        }

        header("Location: index.php?page=kelolauser");
        exit;
    }

    public function editUser()
    {
        $userModel = new User();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $id       = $_POST['id'];
            $name     = $_POST['name'];
            $username = $_POST['username'];
            $role     = $_POST['role'];

            $userModel->update($id, $name, $username, $role);

            header("Location: index.php?page=kelolauser");
            exit;
        }

        $user = null;
        if (isset($_GET['id'])) {
            $user = $userModel->getById($_GET['id']);
        }

        include 'views/admin/Edituser.php';
    }

    public function kelolaUser()
    {
        $user = new User();
        $list = $user->getAllExceptAdmin();

        include 'views/admin/Kelolauser.php';
    }
}
