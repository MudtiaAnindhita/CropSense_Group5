<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'models/User.php';
require_once 'core/AuthHelper.php';

class AuthController
{
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user = new User();
            $result = $user->login($_POST['username'], $_POST['password']);

            if ($result && isset($result['id']) && isset($result['role'])) {
                $_SESSION['user'] = [
                    'id' => $result['id'],
                    'name' => $result['name'],
                    'role' => $result['role']
                ];

                // Arahkan ke dashboard sesuai role
                switch ($result['role']) {
                    case 'mandor':
                        header("Location: index.php?page=dashboardmandor");
                        break;
                    case 'karyawan':
                        header("Location: index.php?page=dashboardkaryawan");
                        break;
                    case 'admin':
                        header("Location: index.php?page=dashboardadmin");
                        break;
                    default:
                        echo "❌ Role tidak dikenali.";
                        session_destroy();
                        break;
                }
                exit;
            } else {
                echo "❌ Login gagal! Username atau password salah.";
            }
        } else {
            include 'views/login.php';
        }
    }

    public function logout()
    {
        session_destroy();
        header("Location: index.php?page=login");
    }

}
