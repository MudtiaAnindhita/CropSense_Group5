<?php
require_once 'models/Panen_model.php';
require_once 'models/Komentar_model.php';
require_once 'models/Karyawan_model.php';
require_once 'core/AuthHelper.php';

class Karyawan
{
    public function dashboardkaryawan()
    {
        $panenModel = new Panen_model();

    $totalPanenHariIni = $panenModel->getTotalHariIni();
    $mutuTerakhir = $panenModel->getMutuTerbaik(); // atau bisa dibuat getMutuTerakhir()

    include 'views/karyawan/dashboard.php';
}
    



    public function laporanharian()
    {
        require_once 'models/Panen_model.php';
        $panenModel = new Panen_model();
        $laporan = $panenModel->getAllLaporan(); // ambil SEMUA data panen
        include 'views/karyawan/laporan.php'; // bikin view baru ini
    }


    public function komentarkaryawan()
    {
        require_once 'models/Komentar_model.php';
        $model = new Komentar_model();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $model->insert($_POST['panen_id'], $_SESSION['user']['id'], $_POST['isi_komentar']);
            header("Location: index.php?page=komentarkaryawan");
            exit;
        }

        // Ambil semua data panen untuk dipilih
        require_once 'models/Panen_model.php';
        $panenModel = new Panen_model();
        $laporan = $panenModel->getAllLaporan(); // atau getByKaryawan(id)

        // Ambil komentar milik user saat ini
        $list = $model->getByKaryawan($_SESSION['user']['id']);

        include 'views/karyawan/komentar.php';
    }



    public function leaderboard()
    {
        $model = new Karyawan_model();
        $data = $model->getLeaderboard();

        include 'views/karyawan/leaderboard.php';
    }

    public function tabelHasil()
    {
        $model = new Panen_model();
        $data = $model->getByKaryawan($_SESSION['user']['id']);

        include 'views/karyawan/tabelHasil.php';
    }
}
