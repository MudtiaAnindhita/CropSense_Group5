<?php
require_once 'models/Mandor_model.php';
require_once 'models/Panen_model.php';
require_once 'models/Grades_model.php';
require_once 'models/Grafik_model.php';
require_once 'models/Kendala_model.php'; // Tambahkan ini supaya tidak error di catatankendalamandor
require_once 'core/AuthHelper.php';

class Mandor
{
    public function __construct()
    {
        if (session_status() == PHP_SESSION_NONE) {
            session_start(); // Tambahkan ini agar session tersedia
        }

        if (!function_exists('requireLogin') || !function_exists('requireRole')) {
            require_once 'core/AuthHelper.php';
        }
        requireLogin();        // Pastikan user sudah login
        requireRole('mandor'); // Batasi akses hanya untuk mandor
    }

    public function dashboard()
    {
        include 'views/mandor/Dashboard.php';
    }
    public function grafik()
    {
        $panenModel = new Panen_model();
        $dataGrafik = $panenModel->getGrafikMingguanMandor(); // Default mingguan

        include 'views/mandor/grafik.php'; // untuk Mandor.php
    }



    public function inputData()
    {
        $karyawanModel = new Mandor_model();
        $karyawan = $karyawanModel->getAllKaryawan();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $panenModel = new Panen_model();
            $karyawan_ids = $_POST['karyawan_id']; // array
            $blok         = $_POST['blok_lokasi'] ?? '';
            $berat        = $_POST['weight'] ?? 0;
            $kematangan   = (int) ($_POST['mutu'] ?? 0);
            $warna        = $_POST['warna'] ?? '';
            $tanggal      = $_POST['tanggal_panen'] ?? '';

            $mandor_id    = $_SESSION['user']['id'];

            // Hitung grade
            if ($kematangan >= 85) {
                $grade = 'A';
            } elseif ($kematangan >= 70) {
                $grade = 'B';
            } else {
                $grade = 'C';
            }

            // Simpan per karyawan
            foreach ($karyawan_ids as $id) {
                $data = [
                    'mandor_id'     => $mandor_id,
                    'karyawan_id'   => $id,
                    'blok_lokasi'   => $blok,
                    'weight'        => $berat,
                    'grades'        => $grade,
                    'color'         => $warna,
                    'tanggal_panen' => $tanggal
                ];

                $panenModel->insert($data);
            }

            header("Location: index.php?page=laporanharian");
            exit;
        }

        include 'views/mandor/InputData.php';
    }

    public function laporanHarian()
    {
        $panenModel = new Panen_model();
        $laporan = $panenModel->getByMandor($_SESSION['user']['id']);

        include 'views/mandor/LaporanHarian.php';
    }

    public function catatankendalamandor()
    {
        $kendalaModel = new Kendala_model();

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $kendalaModel->insert($_SESSION['user']['id'], $_POST['isi_catatan']);
            header("Location: index.php?page=catatankendalamandor");
            exit;
        }

        $data = $kendalaModel->getByMandor($_SESSION['user']['id']);
        include 'views/mandor/CatatanKendala.php';
    }
}
